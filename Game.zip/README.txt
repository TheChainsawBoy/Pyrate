#
Pyrate Game
"Pirate adventure game - explore, loot and battle!"
#

##
Contents
##
- Infinitely, randomly generated islands.
- Lootable islands.
- Compass points to new islands.
- Island types include; normal, village, dinosaurs, treasure, special islands.
- NPC's can be spoken to upon getting close enough.
- Some NPC's give quests.
- Shopkeeper NPC's that sell items.
- Gambling NPC's roll dice to multiply given gold.
- NPC's can be duelled for gold and bounty.
- Gold system.
- Bounty system.
- Inventory for treasures of the sea.
- Enemy ships spawn after searching enough islands.
- Dark water areas that house monsters randomly spawn.
- Get drunk.

###
Controls
###
[W][A][S][D]: Movement.
[F]: Interact.
[TAB]: Open menu (inventory, bounty, quests).
[C]: Fire cannonball.
[ENTER]: Confirm options.